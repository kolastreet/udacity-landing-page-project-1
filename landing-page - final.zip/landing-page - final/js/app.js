/**
 * 
 * Manipulating the DOM exercise.
 * Exercise programmatically builds navigation,
 * scrolls to anchors from navigation,
 * and highlights section in viewport upon scrolling.
 * 
 * Dependencies: None
 * 
 * JS Version: ES2015/ES6
 * 
 * JS Standard: ESlint
 * 
*/

/**
 * Define Global Variables
 * 
*/

/* this code doesnt work on IE */
const sections = document.querySelectorAll('section');
console.log (sections)
//const NumberOfSections = sections.length;
const ullist =  document.getElementById('navbar__list');
const fragment = document.createDocumentFragment();
const navBar = document.getElementById('navbar__list');

let currentViews=[];
let currentVs= [];
// test is just for test .. to make sure code work correctly
let test={};

/**
 * End Global Variables
 * Start Helper Functions
 * 
*/



/**
 * End Helper Functions
 * Begin Main Functions
 * 
*/

for (let i=0; i < sections.length; i++){
	let toTop= window.scrollY;
	console.log(toTop);
 currentViews[i]= Number([sections[i].getBoundingClientRect().top])+toTop;
 currentVs[i]= Number([sections[i].getBoundingClientRect().bottom])+toTop;
 test= sections[i].getBoundingClientRect();
console.log(currentViews,currentVs);
console.log(test);
}




// build the nav

// this is navbar with sections
function sectionlist ()
{ for (let i=0; i < sections.length; i++) 
    { const lists = document.createElement('li');
     const sectionName = sections[i].getAttribute('data-nav');
     const sectionId = sections[i].getAttribute('id');
	
	// console.log(sectionName,sectionId);
	 
   // making list for nav bar
   lists.innerHTML = `<a class ="menu__link" data-id="${sectionId}">${sectionName}</a>`;
   fragment.appendChild(lists);
    }
    // connecting list to navbar__list
    ullist.appendChild(fragment);

}



// view port used https://developer.mozilla.org/en-US/docs/Web/API/Element/getBoundingClientRect

function cviewport (element){
let currentView= element.getBoundingClientRect();
console.log(currentView);
//return (currentView.top>=0 && currentView.left>=0);
return (currentView);
}





function activeSection () {
	var view = window.visualViewport.pageTop;
	//in some browers i need 1 px difference since numbers from getBoundingClientRect are float and window.visualViewport.pageTop are integer  
	view=view+1;
	console.log(view);
	
let active = document.querySelectorAll('ul li');
 
   for (let i=0; i < (sections.length); i++){
sections[i].classList.remove("your-active-class"); 
	active[i].children[0].classList.remove('active');} 

 for (let i=0; i < (sections.length); i++) {
   
	if (Number(currentViews[i])<=Number(view)&&Number(view)<Number(currentVs[i]))
	{
		console.log(Number(currentViews[i]),view,Number(currentVs[i]));
 sections[i].classList.add("your-active-class");

 //console.log(active[i].classList);
 active[i].children[0].classList.add('active');
 
	}

 }

}

// Scroll to anchor ID using scrollTO event

function scrollToElement(event){
  
      const sectionId = event.target.getAttribute('data-id');
      const currentSection = document.getElementById(sectionId);
	  
      // as in mozilla doc https://developer.mozilla.org/en-US/docs/Web/API/Element/scrollIntoView
      currentSection.scrollIntoView({behavior: "smooth",block: "start"});
  
}

// active scrolling after clicking on bar

navBar.addEventListener('click', function(event){
    scrollToElement(event)
})

// active event for active section

document.addEventListener('scroll', function(){
 activeSection();
});






/**
 * End Main Functions
 * Begin Events
 * 
*/
sectionlist ();
// Build menu 

// Scroll to section on link click

// Set sections as active


